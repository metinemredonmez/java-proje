package com.javacourse.project.hibernateAndJpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HibernateAndJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
